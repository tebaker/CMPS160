Talon Baker
Assignment 5: Creating a Virtual World
https://people.ucsc.edu/~taebaker/CMPS160/ASSG_05/driver.html