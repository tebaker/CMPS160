Talon Baker
Assignment 2 - Painting Geometric Shapes
https://people.ucsc.edu/~taebaker/CMPS160/ASSG_02/driver.html